using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.RuleTile.TilingRuleOutput;
using UnityEngine.UIElements;

public class PowerUp : MonoBehaviour
{
    public float moveSpeed = 1.0f;
    public float dirChangeTime = 5.0f;
    public float selfDestroyTime = 10.0f;
    Vector2 dir;

    Player player;

    WaitForSeconds waitTime;

    public GameObject powerup;


    private void Start()
    {
        waitTime = new WaitForSeconds(dirChangeTime);
        player = FindObjectOfType<Player>();
        SetRandomDir();
        StartCoroutine(DirChange());
        Destroy(this.gameObject, selfDestroyTime);
    }

    private void Update()
    { 
        
        transform.Translate(moveSpeed * Time.deltaTime * dir);

    }

    IEnumerator DirChange()
    {
        while(true)
        {
            yield return waitTime;
            SetRandomDir(false);
        }
    }

    void SetRandomDir(bool allRandom = true)  // ����Ʈ �Ķ����. ���� �������� ������ ����Ʈ ���� ��� ����.
    {
        if (allRandom)
        {
            dir = Random.insideUnitCircle;
            dir = dir.normalized;
        }
        else
        {
            Vector2 playerToPowerUp = transform.position - player.transform.position;
            playerToPowerUp = playerToPowerUp.normalized;

            if (Random.value < 0.6) // 60%Ȯ��
            {
                // playerToPowerUp ���͸� z ������ -90~+90 ��ŭ ȸ�����Ѽ� dir �� �ֱ�
                dir = Quaternion.Euler(0, 0, Random.Range(-90.0f, 90.0f)) * playerToPowerUp;
            }
            else // 40%Ȯ��
            {
               
                dir = Quaternion.Euler(0, 0, Random.Range(-90.0f, 90.0f)) * playerToPowerUp;
            }
              
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Border"))
        {
            dir = Vector2.Reflect(dir, collision.contacts[0].normal);
   
        }
    }

}
